package com.example.projectakhir

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.projectakhir.data.room.AppViewModel
import com.example.projectakhir.data.room.PostDatabase
import com.example.projectakhir.data.room.RoomViewModelFactory
import com.example.projectakhir.utils.reduceFileImage
import com.example.projectakhir.utils.uriToFile
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.projectakhir.R
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class AddPost : AppCompatActivity() {
    private var currentImageUri: Uri? = null
    private lateinit var playerImage: ImageView
    private lateinit var appViewModel: AppViewModel
    private lateinit var playerName: TextInputEditText
    private lateinit var playerDescription: TextInputEditText

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.post)

        val username = intent.getStringExtra("USERNAME")

        val factory = RoomViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]


        playerImage = findViewById(R.id.up_gambarBaru)
        playerName = findViewById(R.id.add_title)
        playerDescription = findViewById(R.id.add_desc)

        onClick()

        val back = findViewById<ImageButton>(R.id.btn_back)
        back.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("USERNAME", username)
            startActivity(intent)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun onClick() {
        val openImagePicker = findViewById<ImageView>(R.id.up_gambarBaru)
        openImagePicker.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri"
                    isShowCamera = false
                    imageTitle = "Tekan untuk memilih gambar"
                    doneButtonText = "Selesai"
                }
            )
        }

        val btnSavedPlayer = findViewById<MaterialButton>(R.id.btn_posting)
        btnSavedPlayer.setOnClickListener {
            if (validateInput()) {
                savedData()
            }
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (playerName.text.toString().isEmpty()) {
            error++
            playerName.error = "Judul tidak boleh kosong"
        }

        if (playerDescription.text.toString().isEmpty()) {
            error++
            playerDescription.error = "Deskripsi tidak boleh kosong"
        }

        if (currentImageUri == null) {
            error++
            Toast.makeText(this, "Gambar tidak boleh kosong", Toast.LENGTH_SHORT).show()
        }

        return error == 0
    }

    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            playerImage.visibility = View.VISIBLE
            currentImageUri = firstImage.uri
            Glide.with(playerImage)
                .load(firstImage.uri)
                .into(playerImage)
        } else {
            playerImage.visibility = View.GONE
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun savedData() {
        val imageFile = currentImageUri?.let { uriToFile(it, this).reduceFileImage() }
        val TanggalUnggah = LocalDate.now()
        val jam = LocalTime.now().withSecond(0).withNano(0)

        val formatter = DateTimeFormatter.ofPattern("HH:mm")
        val waktuUnggah = "$TanggalUnggah ${jam.format(formatter)}"

        val username = intent.getStringExtra("USERNAME")


        val player = imageFile?.let {
            PostDatabase(
                judul = playerName.text.toString(),
                username = "$username",
                description = playerDescription.text.toString(),
                likes = 0,
                waktu = waktuUnggah,
                image = imageFile
            )
        }

        if (player != null) appViewModel.insertPost(post = player)

        Toast.makeText(
            this@AddPost,
            "Postingan Berhasil Diunggah",
            Toast.LENGTH_SHORT
        ).show()

        finish()
    }
}
