package com.example.projectakhir

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectakhir.adapter.ContentAdapter
import com.example.projectakhir.data.retrofit.APIresponse
import com.example.projectakhir.data.retrofit.ContentViewModel
import com.example.projectakhir.data.retrofit.ContentViewModelFactory
import com.projectakhir.R

class ApiFragment : Fragment(R.layout.fragmen_api) {
    private lateinit var contentViewModel: ContentViewModel
    private lateinit var adapter: ContentAdapter

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        contentViewModel = ViewModelProvider(this, ContentViewModelFactory.getInstance())[ContentViewModel::class.java]

        val rvContent = view.findViewById<RecyclerView>(R.id.rv_api)
        rvContent.layoutManager = LinearLayoutManager(context)

        contentViewModel.getAllContent()
        contentViewModel.listContent.observe(viewLifecycleOwner) { content ->
            if (content.isNotEmpty()) {
                adapter = ContentAdapter(content)
                rvContent.adapter = adapter

                adapter.setOnItemClickCallback(object : ContentAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIresponse) {
                        // Handle item click for API data
                        val navigateToDetail = Intent(context, DetailActivity::class.java)
                        navigateToDetail.putExtra("apiData", data)
                        startActivity(navigateToDetail)
                    }
                })
            }
        }
    }
}
