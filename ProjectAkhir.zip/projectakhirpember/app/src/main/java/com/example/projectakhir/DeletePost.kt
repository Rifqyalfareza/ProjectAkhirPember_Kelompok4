package com.example.projectakhir

class DeletePost {
}