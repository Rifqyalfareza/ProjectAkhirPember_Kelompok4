package com.example.projectakhir

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.projectakhir.adapter.PostAdapterRoom
import com.example.projectakhir.data.retrofit.APIresponse
import com.example.projectakhir.data.room.AppViewModel
import com.example.projectakhir.data.room.PostDatabase
import com.google.android.material.imageview.ShapeableImageView
import com.projectakhir.R

class DetailActivity : AppCompatActivity() {
    private lateinit var appViewModel: AppViewModel

    private lateinit var playerAdapterRoom: PostAdapterRoom

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)


        val getData = intent.getParcelableExtra<PostDatabase>("budaya")
        val getDataApi = intent.getParcelableExtra<APIresponse>("apiData")

        // Menghubungkan variabel dengan komponen di layout
        val btn_more = findViewById<ImageButton>(R.id.btn_opsi)
        val title = findViewById<TextView>(R.id.detail_title)
        val foto = findViewById<ShapeableImageView>(R.id.shapeableImageView)
        var back = findViewById<ImageButton>(R.id.btn_back_detail)
        val tgl = findViewById<TextView>(R.id.tgl_up)
        val desc = findViewById<TextView>(R.id.detail_deskripsi)

        if (getDataApi != null) {
            title.text = getDataApi.judul
            desc.text = getDataApi.deskripsi
            Glide.with(this)
                .load(getDataApi.image)
                .into(foto)
        } else if (getData != null) {
            title.text = getData.judul
            desc.text = getData.description
            // Misalkan getData.waktu adalah sebuah string
            tgl.text = "Di upload pada : ${getData.waktu}"
            Glide.with(this)
                .load(getData.image)
                .into(foto)
        } else {
            // Handle the case where both getData and getDataApi are null
            title.text = "No Data Available"
            desc.text = ""
            tgl.text = ""
        }

        onClick()

        btn_more.setOnClickListener {
            if (getData != null) {
                PopUpActivity(getData, 0).show(supportFragmentManager, PopUpActivity.TAG)
            }
        }
    }


    private fun onClick(){
        val btnBack = findViewById<ImageButton>(R.id.btn_back_detail)
        btnBack.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }


}