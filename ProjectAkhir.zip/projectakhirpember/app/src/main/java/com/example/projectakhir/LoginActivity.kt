package com.example.projectakhir


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.projectakhir.data.room.UserAppDatabase
import com.example.projectakhir.data.room.UserRepository
import com.example.projectakhir.data.room.UserViewModel
import com.example.projectakhir.data.room.UserViewModelFactory
import com.projectakhir.R

class LoginActivity : AppCompatActivity() {

    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val database = UserAppDatabase.getDatabase(this)
        val repository = UserRepository(database.userDao())
        userViewModel = ViewModelProvider(this, UserViewModelFactory(repository))[UserViewModel::class.java]

        val usernameEditText = findViewById<EditText>(R.id.usernameTextInputLayout)
        val passwordEditText = findViewById<EditText>(R.id.passwordTextInputLayout)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val registerButton = findViewById<TextView>(R.id.forgotPasswordTextView)

        registerButton.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()
            if (username.isNotEmpty() && password.isNotEmpty()) {
                userViewModel.login(username, password) { user ->
                    runOnUiThread {
                        if (user != null) {
                            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this, MainActivity::class.java)
                            intent.putExtra("USERNAME", username)
                            startActivity(intent)
                        } else {
                            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            }
        }

    }
}