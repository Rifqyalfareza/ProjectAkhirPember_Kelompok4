package com.example.projectakhir
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectakhir.AddPost
import com.example.projectakhir.DetailActivity
import com.example.projectakhir.adapter.ContentAdapter
import com.example.projectakhir.adapter.PostAdapterRoom
import com.example.projectakhir.data.retrofit.APIresponse
import com.example.projectakhir.data.retrofit.ContentViewModel
import com.example.projectakhir.data.retrofit.ContentViewModelFactory
import com.example.projectakhir.data.room.AppViewModel
import com.example.projectakhir.data.room.PostDatabase
import com.example.projectakhir.data.room.RoomViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textview.MaterialTextView
import com.projectakhir.R
import java.time.LocalTime

class MainActivity : AppCompatActivity() {
    private lateinit var appViewModel: AppViewModel
    private lateinit var contentViewModel: ContentViewModel // Assuming ContentViewModel exists
    private lateinit var playerAdapterRoom: PostAdapterRoom
    private lateinit var adapter: ContentAdapter
    private lateinit var recyclerView: RecyclerView

    @SuppressLint("MissingInflatedId")
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = intent.getStringExtra("USERNAME")

        val pnulis = findViewById<TextView>(R.id.textView2)
        pnulis.text = "Welcome, $username"


        // Inisialisasi ViewModel untuk Room
        val factoryRoom = RoomViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factoryRoom)[AppViewModel::class.java]

//        // Inisialisasi ViewModel untuk API
//        val factoryContent = ContentViewModelFactory.getInstance()
//        contentViewModel = ViewModelProvider(this, factoryContent)[ContentViewModel::class.java]

        // Inisialisasi RecyclerView untuk data dari Room
        recyclerView = findViewById(R.id.konten)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Observing data dari Room dan memperbarui RecyclerView
        appViewModel.getAllPost().observe(this) { postData ->
            if (postData != null) {
                playerAdapterRoom = PostAdapterRoom(postData)
                recyclerView.adapter = playerAdapterRoom

                playerAdapterRoom.setOnItemClickCallback(object : PostAdapterRoom.OnItemClickCallback {
                    override fun onItemClicked(data: PostDatabase) {
                        showSelectedPost(data)
                    }
                })
            }
        }

        // Inisialisasi RecyclerView untuk data dari API
//        val rvContent = findViewById<RecyclerView>(R.id.konten)
//        rvContent.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
//
//        // Observing data dari API dan memperbarui RecyclerView
//        contentViewModel.getAllContent()
//        contentViewModel.listContent.observe(this) { content ->
//            if (content.isNotEmpty()) {
//                adapter = ContentAdapter(content)
//                rvContent.adapter = adapter
//
//                adapter.setOnItemClickCallback(object : ContentAdapter.OnItemClickCallback {
//                    override fun onItemClicked(data: APIresponse) {
//                        // Handle item click for API data
//                         showSelectedPost(data)
//                    }
//                })
//            }
//        }

        // Handling klik tombol tambah untuk pindah ke AddPost activity
        val post: FloatingActionButton = findViewById(R.id.addButton)
        post.setOnClickListener {
            val intent = Intent(this, AddPost::class.java)
            intent.putExtra("USERNAME", username)
            startActivity(intent)
        }

        val rv : FloatingActionButton = findViewById(R.id.rv_ke_api)
        rv.setOnClickListener{
            val intent = Intent(this,apiview::class.java)
            startActivity(intent)
        }
    }
    private fun showSelectedPost(data: Any) {
        when (data) {
            is PostDatabase -> {
                // Data berasal dari Room (PostDatabase)
                val navigateToDetail = Intent(this, DetailActivity::class.java)
                navigateToDetail.putExtra("budaya", data)
                startActivity(navigateToDetail)
            }
            is APIresponse -> {
                // Data berasal dari API (APIresponse)
                // Contoh implementasi untuk menangani data dari APIresponse
                // Jika Anda memiliki DetailActivity untuk menampilkan detail APIresponse,
                // sesuaikan dengan cara yang sesuai untuk memasukkan data APIresponse ke Intent.
                // Misalnya:
                 val navigateToDetail = Intent(this, DetailActivity::class.java)
                 navigateToDetail.putExtra("apiData", data)
                 startActivity(navigateToDetail)
            }
            else -> {
                // Handle jika tipe data tidak dikenali
                // Misalnya, tipe data lain dari sumber lainnya
            }
        }
    }

//    private fun showSelectedPost(data: PostDatabase) {
//        // Intent untuk pindah ke DetailActivity dengan data PostDatabase
//        val navigateToDetail = Intent(this, DetailActivity::class.java)
//        navigateToDetail.putExtra("budaya", data)
//        startActivity(navigateToDetail)
//    }
}
