package com.example.projectakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.projectakhir.data.room.User
import com.example.projectakhir.data.room.UserAppDatabase
import com.example.projectakhir.data.room.UserRepository
import com.example.projectakhir.data.room.UserViewModel
import com.example.projectakhir.data.room.UserViewModelFactory
import com.projectakhir.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val database = UserAppDatabase.getDatabase(this)
        val repository = UserRepository(database.userDao())
        userViewModel = ViewModelProvider(this, UserViewModelFactory(repository)).get(UserViewModel::class.java)

        val nama = findViewById<EditText>(R.id.usernameTextInputLayout2)
        val usernameEditText = findViewById<EditText>(R.id.usernameTextInputLayout)
        val passwordEditText = findViewById<EditText>(R.id.id_password)
        val registerButton = findViewById<Button>(R.id.regisButton)
        val textlogin = findViewById<TextView>(R.id.textlogin)

        textlogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                val user = User(username = username, password = password)
                insertUser(user)
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun insertUser(user: User) {
        CoroutineScope(Dispatchers.IO).launch {
            userViewModel.insert(user)
            runOnUiThread {
                Toast.makeText(this@RegisterActivity, "User registered successfully!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}