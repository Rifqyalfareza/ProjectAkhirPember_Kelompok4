package com.example.projectakhir

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectakhir.adapter.PostAdapterRoom
import com.example.projectakhir.data.room.AppViewModel
import com.example.projectakhir.data.room.PostDatabase
import com.example.projectakhir.data.room.RoomViewModelFactory
import com.projectakhir.R

class RoomFragment : Fragment(R.layout.fragmen_room) {
    private lateinit var appViewModel: AppViewModel
    private lateinit var playerAdapterRoom: PostAdapterRoom

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        appViewModel = ViewModelProvider(this, RoomViewModelFactory.getInstance(requireContext()))[AppViewModel::class.java]

        val rvRoom = view.findViewById<RecyclerView>(R.id.rv_room)
        rvRoom.layoutManager = LinearLayoutManager(context)

        appViewModel.getAllPost().observe(viewLifecycleOwner) { postData ->
            if (postData != null) {
                playerAdapterRoom = PostAdapterRoom(postData)
                rvRoom.adapter = playerAdapterRoom

                playerAdapterRoom.setOnItemClickCallback(object : PostAdapterRoom.OnItemClickCallback {
                    override fun onItemClicked(data: PostDatabase) {
                        val navigateToDetail = Intent(context, DetailActivity::class.java)
                        navigateToDetail.putExtra("budaya", data)
                        startActivity(navigateToDetail)
                    }
                })
            }
        }
    }
}
