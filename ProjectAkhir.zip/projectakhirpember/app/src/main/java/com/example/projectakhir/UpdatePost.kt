package com.example.projectakhir

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.projectakhir.data.room.AppViewModel
import com.example.projectakhir.data.room.PostDatabase
import com.example.projectakhir.data.room.RoomViewModelFactory
import com.example.projectakhir.utils.reduceFileImage
import com.example.projectakhir.utils.uriToFile
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.projectakhir.R
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class UpdatePost : AppCompatActivity() {
    private var currentImageUri: Uri? = null
    private var oldImageUri: File? = null

    private lateinit var Image: ImageView

    private lateinit var appViewModel: AppViewModel

    private lateinit var Deskripsi: TextInputEditText

    private lateinit var judul : TextInputEditText

    private lateinit var kontenGambar: TextInputLayout

    private lateinit var getData: PostDatabase

    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            // Menampilkan ImageView jika gambar berhasil dipilih
            Image.visibility = View.VISIBLE
            // Menyimpan URI gambar yang dipilih
            currentImageUri = firstImage.uri
            // Menampilkan pesan bahwa gambar berhasil dimasukkan
//            kontenGambar.setText("Change")
            Image.setImageURI(currentImageUri)

            // Menggunakan library Glide untuk menampilkan gambar yang dipilih
//            Glide.with(kontenImage)
//                .load(firstImage.uri)
//                .into(kontenImage)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)



        getData = intent.getParcelableExtra("id")!!

        val factory = RoomViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        Image = findViewById(R.id.up_gambar)
        judul = findViewById(R.id.edit_title)
        Deskripsi = findViewById(R.id.edit_desc)
        kontenGambar = findViewById(R.id.edit_foto)


        judul.setText(getData.judul)
        Deskripsi.setText(getData.description)
//        kontenGambar.setText("Change")

        oldImageUri = getData.image
        val uri = Uri.fromFile(oldImageUri)
        Image.setImageURI(uri)
        Image.visibility = View.VISIBLE


        onClick()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun onClick(){
        val btnSave = findViewById<MaterialButton>(R.id.btn_update)
        btnSave.setOnClickListener {
            if(validateInput()){

                savedData()
            }
        }

        val openImagePicker = findViewById<TextInputEditText>(R.id.unggah_foto)
        openImagePicker.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri"
                    isShowCamera = false
                    imageTitle = "Tekan untuk memilih gambar"
                    doneButtonText = "Selesai"
                }
            )
        }
        val username = intent.getStringExtra("USERNAME")


        val btnBack = findViewById<ImageButton>(R.id.btn_back_edit)
        btnBack.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("USERNAME", username)
            startActivity(intent)
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (judul.text.toString().isEmpty()) {
            error++
            judul.error = "Nama tidak boleh kosong"
        }
//        if (playerUsername.text.toString().isEmpty()) {
//            error++
//            playerUsername.error = "Username tidak boleh kosong"
//        }
        if (Deskripsi.text.toString().isEmpty()) {
            error++
            Deskripsi.error = "Deskripsi tidak boleh kosong"
        }
        if (kontenGambar == null) {
            error++
            Toast.makeText(this, "Gambar tidak boleh kosong", Toast.LENGTH_SHORT).show()
        }

        return error == 0
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun savedData() {
        // Mengubah URI gambar menjadi file dan mengurangi ukuran file
        val imageFile = currentImageUri?.let { uriToFile(it, this).reduceFileImage() }
        val TanggalUnggah = LocalDate.now()
        val jam = LocalTime.now().withSecond(0).withNano(0) // Menghilangkan detik dan milidetik

        val formatter = DateTimeFormatter.ofPattern("HH:mm")
        val waktuUnggah = "$TanggalUnggah ${jam.format(formatter)}"

        val username = intent.getStringExtra("USERNAME")


        // Membuat objek pemain dengan data yang diinputkan
        val player = (if (currentImageUri != null) imageFile else oldImageUri)?.let {
            PostDatabase(
                id = getData.id,
                judul = judul.text.toString(),
                username = "Admin",
                description = Deskripsi.text.toString(),
                likes = 0,
                waktu = waktuUnggah,
                image = it
            )
        }

        // Menyimpan data pemain ke database
        if (player != null) appViewModel.updatePost(player)

        // Menampilkan pesan bahwa data pemain berhasil ditambahkan
        Toast.makeText(
            this@UpdatePost,
            "Postingan Berhasil diubah",
            Toast.LENGTH_SHORT
        ).show()

        // Mengakhiri activity
        finish()
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("USERNAME", username)
        startActivity(intent)
    }
}