package com.example.projectakhir.data.retrofit

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class APIRepository {
    private val _listContent = MutableLiveData<List<APIresponse>>()
    val listContent: LiveData<List<APIresponse>> = _listContent

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun getAllContent() {
        _isLoading.value = true
        val service = APIconfig.getApiService().getAllKonten()
        service.enqueue(object : Callback<List<APIresponse>> {
            override fun onResponse(
                call: Call<List<APIresponse>>,
                response: Response<List<APIresponse>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _listContent.value = response.body(); val responseBody = response.body()
                    Log.d("API Response", "Received response: $responseBody")
                } else {
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<APIresponse>>, t: Throwable) {
                _isLoading.value = false
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }
}