package com.example.projectakhir.data.retrofit

import retrofit2.Call
import retrofit2.http.GET

interface APIService {
    @GET("konten")
    fun getAllKonten(): Call<List<APIresponse>>
}