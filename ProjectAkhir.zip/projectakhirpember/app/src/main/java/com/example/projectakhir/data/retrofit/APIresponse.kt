package com.example.projectakhir.data.retrofit

import android.os.Parcel
import android.os.Parcelable

data class APIresponse(
    val id: Int,
    val judul: String,
    val deskripsi: String,
    val image: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(judul)
        parcel.writeString(deskripsi)
        parcel.writeString(image)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<APIresponse> {
        override fun createFromParcel(parcel: Parcel): APIresponse {
            return APIresponse(parcel)
        }

        override fun newArray(size: Int): Array<APIresponse?> {
            return arrayOfNulls(size)
        }
    }
}
