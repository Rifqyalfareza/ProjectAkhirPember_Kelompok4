package com.example.projectakhir.data.retrofit

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.projectakhir.data.retrofit.APIRepository
import com.example.projectakhir.data.retrofit.APIresponse
//import com.example.projectakhir.data.retrofit.ContentList

class ContentViewModel(private val apiRepository: APIRepository) : ViewModel() {
    // Mendeklarasikan variabel listPlayer yang berisi LiveData dari List APIResponse dari repository
    val listContent: LiveData<List<APIresponse>> = apiRepository.listContent

    // Mendeklarasikan variabel isLoading yang berisi LiveData dari Boolean (status loading) dari repository
    val isLoading: LiveData<Boolean> = apiRepository.isLoading

    // Fungsi untuk mendapatkan semua data dari repository
    fun getAllContent() {
        apiRepository.getAllContent()
    }
}