package com.example.projectakhir.data.room

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class UserViewModel(private val repository: UserRepository) : ViewModel() {

    fun insert(user: User) = viewModelScope.launch {
        viewModelScope.launch {
            repository.insert(user)
        }
    }

    fun login(username: String, password: String, callback: (User?) -> Unit) = viewModelScope.launch {
        withContext(Dispatchers.IO) {
            val user = repository.getUser(username, password)
            callback(user)
        }
    }
}